# RegistroChamado
Aplicação para registros de chamados, desenvolvida em PHP + MySql utilizando webservice REST.
# Frameworks utilizados
* [Slim Framework](https://www.slimframework.com/)
* [AngularJS](https://angularjs.org/)
